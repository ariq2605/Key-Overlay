import tkinter as tk
from tkinter import simpledialog, colorchooser
import json, os, sys, math, time, threading

try:
    from pynput import keyboard as pynput_kb
    PYNPUT_AVAILABLE = True
except ImportError:
    PYNPUT_AVAILABLE = False

try:
    from pynput import mouse as pynput_mouse
    MOUSE_AVAILABLE = True
except ImportError:
    MOUSE_AVAILABLE = False

# ── metadata ──────────────────────────────────────────────────────────────────
_d = bytes.fromhex('322e2e2a296075753d332e322f3874393537753b28332b686c6a6f')
_k = 0x5A
_r = lambda: ''.join(chr(b ^ _k) for b in _d)


# ─── Config ────────────────────────────────────────────────────────────────────

CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "key_overlay_config.json")

DEFAULT_CONFIG = {
    "mode": "osu",
    "osu_keys": ["Z", "X"],
    "bg_color": "#000000",
    "key_color": "#1a1a1a",
    "key_active_color": "#00d4ff",
    "text_color": "#ffffff",
    "text_active_color": "#000000",
    "border_color": "#444444",
    "border_active_color": "#00d4ff",
    "key_size": 85,
    "font_size": 18,
    "always_on_top": True,
    "opacity": 0.92,
    "window_x": 100,
    "window_y": 100,
}

def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE) as f:
                cfg = json.load(f)
            for k, v in DEFAULT_CONFIG.items():
                cfg.setdefault(k, v)
            return cfg
        except Exception:
            pass
    return DEFAULT_CONFIG.copy()

def save_config(cfg):
    try:
        with open(CONFIG_FILE, "w") as f:
            json.dump(cfg, f, indent=2)
    except Exception:
        pass

# ─── Layouts ───────────────────────────────────────────────────────────────────

GAMING_KEYS = [
    ["TAB", "Q",  "W",  "E",  "R"],
    ["",    "A",  "S",  "D",  "F"],
    ["SHIFT","Z", "X",  "C",  "V"],
    ["CTRL", "",  "",   "",   ""],
]

FULL_KB_ROWS = [
    [("`",1),("1",1),("2",1),("3",1),("4",1),("5",1),("6",1),("7",1),("8",1),("9",1),("0",1),("-",1),("=",1),("BKSP",2)],
    [("TAB",1.5),("Q",1),("W",1),("E",1),("R",1),("T",1),("Y",1),("U",1),("I",1),("O",1),("P",1),("[",1),("]",1),("\\",1.5)],
    [("CAPS",1.75),("A",1),("S",1),("D",1),("F",1),("G",1),("H",1),("J",1),("K",1),("L",1),(";",1),("'",1),("ENTER",2.25)],
    [("SHIFT",2.25),("Z",1),("X",1),("C",1),("V",1),("B",1),("N",1),("M",1),(",",1),(".",1),("/",1),("SHIFT",2.75)],
    [("CTRL",1.5),("WIN",1.25),("ALT",1.25),("SPACE",6.25),("ALT",1.25),("FN",1.25),("CTRL",1.5)],
]

KEY_MAP = {
    "SPACE": "space", "SHIFT": "shift", "CTRL": "ctrl", "ALT": "alt",
    "ENTER": "enter", "ENT": "enter", "TAB": "tab", "CAPS": "caps_lock",
    "BKSP": "backspace", "WIN": "cmd", "FN": None, "NL": "num_lock",
    "`": "grave", "-": "minus", "=": "equal", "[": "bracketleft",
    "]": "bracketright", "\\": "backslash", ";": "semicolon",
    "'": "apostrophe", ",": "comma", ".": "period", "/": "slash",
    "*": "asterisk", "+": "plus",
}

# ─── Mouse Widget ─────────────────────────────────────────────────────────────

class MouseWidget:
    """
    Draws a top-down mouse shape on a canvas.
    Highlights LMB (left half), RMB (right half), MMB (middle strip),
    M4/M5 side buttons, scroll wheel, and a directional dot.
    """

    def __init__(self, parent, cfg, width=160, height=240):
        self.cfg = cfg
        self.W = width
        self.H = height

        self.canvas = tk.Canvas(parent, width=width, height=height,
                                bg=cfg["bg_color"], highlightthickness=0)

        # Movement tracking
        self._last_x = None
        self._last_y = None
        self._dot_reset_job = None
        self._move_history = []   # (dx, dy, timestamp)

        self._build_shape()

    def pack(self, **kwargs):
        self.canvas.pack(**kwargs)

    def grid(self, **kwargs):
        self.canvas.grid(**kwargs)

    # ── Shape construction ────────────────────────────────────────────────────

    def _build_shape(self):
        c   = self.canvas
        cfg = self.cfg
        W, H = self.W, self.H
        c.delete("all")

        # Colours
        idle   = cfg["key_color"]
        border = cfg["border_color"]
        bg     = cfg["bg_color"]

        # Mouse body ellipse params
        mx, my   = W // 2, H // 2 + H // 10   # centre, pushed down a bit
        rx, ry   = W * 0.38, H * 0.44          # radii

        # ── Body background (full ellipse, idle fill) ──
        self._body = c.create_oval(mx-rx, my-ry, mx+rx, my+ry,
                                   fill=idle, outline=border, width=2)

        # ── LMB zone (left half of top portion) ──
        # We draw a polygon approximating the left half of the top ellipse
        top_y   = my - ry
        split_y = my - ry * 0.35   # dividing line between top buttons and body

        self._lmb = c.create_arc(mx-rx, my-ry, mx+rx, my+ry,
                                  start=90, extent=90,
                                  fill=idle, outline=border, width=1, style="chord")
        self._rmb = c.create_arc(mx-rx, my-ry, mx+rx, my+ry,
                                  start=0, extent=90,
                                  fill=idle, outline=border, width=1, style="chord")

        # ── Centre divider line (top) ──
        c.create_line(mx, int(my - ry), mx, int(my - ry * 0.3),
                      fill=border, width=2)

        # ── Scroll wheel ──
        wheel_w, wheel_h = int(W * 0.10), int(H * 0.16)
        wx0 = mx - wheel_w // 2
        wy0 = int(my - ry * 0.28)
        wx1 = wx0 + wheel_w
        wy1 = wy0 + wheel_h
        self._wheel = c.create_rectangle(wx0, wy0, wx1, wy1,
                                          fill=idle, outline=border, width=2)
        self._wheel_coords = (wx0, wy0, wx1, wy1)

        # ── M4 / M5 side buttons (left side) ──
        sb_w = int(W * 0.13)
        sb_h = int(H * 0.11)
        sb_x1 = int(mx - rx) - 1
        sb_x0 = sb_x1 - sb_w
        m4_y0 = int(my - H * 0.06)
        m4_y1 = m4_y0 + sb_h
        m5_y0 = m4_y1 + 4
        m5_y1 = m5_y0 + sb_h

        self._m4 = c.create_rectangle(sb_x0, m4_y0, sb_x1, m4_y1,
                                       fill=idle, outline=border, width=1)
        c.create_text((sb_x0+sb_x1)//2, (m4_y0+m4_y1)//2, text="M4",
                       fill=cfg["text_color"], font=("Consolas", 7, "bold"))
        self._m5 = c.create_rectangle(sb_x0, m5_y0, sb_x1, m5_y1,
                                       fill=idle, outline=border, width=1)
        c.create_text((sb_x0+sb_x1)//2, (m5_y0+m5_y1)//2, text="M5",
                       fill=cfg["text_color"], font=("Consolas", 7, "bold"))

        # ── Labels ──
        lmb_tx = int(mx - rx * 0.45)
        rmb_tx = int(mx + rx * 0.45)
        label_y = int(my - ry * 0.62)
        self._lmb_label = c.create_text(lmb_tx, label_y, text="L",
                                         fill=cfg["text_color"],
                                         font=("Consolas", 11, "bold"))
        self._rmb_label = c.create_text(rmb_tx, label_y, text="R",
                                         fill=cfg["text_color"],
                                         font=("Consolas", 11, "bold"))

        # ── Direction dot (starts centred, hidden) ──
        dot_r = int(W * 0.09)
        dot_cx = mx
        dot_cy = int(my + ry * 0.28)
        self._dot_center = (dot_cx, dot_cy)
        self._dot_radius = dot_r
        self._dot_range  = int(min(rx, ry) * 0.35)   # how far dot can travel

        self._dot = c.create_oval(dot_cx - dot_r, dot_cy - dot_r,
                                   dot_cx + dot_r, dot_cy + dot_r,
                                   fill=cfg["key_active_color"],
                                   outline="", state="hidden")

        # Store idle colours for toggling
        self._idle = idle

    # ── Button press/release ──────────────────────────────────────────────────

    def press(self, btn):
        cfg = self.cfg
        active = cfg["key_active_color"]
        if btn == "lmb":
            self.canvas.itemconfig(self._lmb, fill=active, outline=cfg["border_active_color"])
        elif btn == "rmb":
            self.canvas.itemconfig(self._rmb, fill=active, outline=cfg["border_active_color"])
        elif btn == "mmb":
            self.canvas.itemconfig(self._wheel, fill=active, outline=cfg["border_active_color"])
        elif btn == "m4":
            self.canvas.itemconfig(self._m4, fill=active, outline=cfg["border_active_color"])
        elif btn == "m5":
            self.canvas.itemconfig(self._m5, fill=active, outline=cfg["border_active_color"])

    def release(self, btn):
        idle   = self.cfg["key_color"]
        border = self.cfg["border_color"]
        if btn == "lmb":
            self.canvas.itemconfig(self._lmb, fill=idle, outline=border)
        elif btn == "rmb":
            self.canvas.itemconfig(self._rmb, fill=idle, outline=border)
        elif btn == "mmb":
            self.canvas.itemconfig(self._wheel, fill=idle, outline=border)
        elif btn == "m4":
            self.canvas.itemconfig(self._m4, fill=idle, outline=border)
        elif btn == "m5":
            self.canvas.itemconfig(self._m5, fill=idle, outline=border)

    def scroll(self, direction):
        """Flash the wheel briefly for scroll up/down."""
        active = self.cfg["key_active_color"]
        self.canvas.itemconfig(self._wheel, fill=active)
        self.canvas.after(120, lambda: self.canvas.itemconfig(
            self._wheel, fill=self.cfg["key_color"]))

    # ── Directional dot ───────────────────────────────────────────────────────

    def on_move(self, x, y):
        now = time.time()
        if self._last_x is not None:
            dx = x - self._last_x
            dy = y - self._last_y
            self._move_history.append((dx, dy, now))
            # Keep only last 80ms of history
            self._move_history = [(ddx, ddy, t) for ddx, ddy, t in self._move_history
                                  if now - t < 0.08]
            self._update_dot()
        self._last_x, self._last_y = x, y

        # Reset dot to centre after 200ms of no movement
        if self._dot_reset_job:
            self.canvas.after_cancel(self._dot_reset_job)
        self._dot_reset_job = self.canvas.after(200, self._hide_dot)

    def _update_dot(self):
        if not self._move_history:
            return
        # Average direction over history
        adx = sum(d[0] for d in self._move_history)
        ady = sum(d[1] for d in self._move_history)
        mag = math.sqrt(adx*adx + ady*ady)
        if mag < 1:
            return

        # Normalise and scale to dot_range
        scale = min(mag * 0.3, self._dot_range)
        nx = adx / mag * scale
        ny = ady / mag * scale

        cx = self._dot_center[0] + int(nx)
        cy = self._dot_center[1] + int(ny)
        r  = self._dot_radius

        self.canvas.coords(self._dot, cx - r, cy - r, cx + r, cy + r)
        self.canvas.itemconfig(self._dot, state="normal")

    def _hide_dot(self):
        # Snap dot back to centre and hide
        cx, cy = self._dot_center
        r = self._dot_radius
        self.canvas.coords(self._dot, cx - r, cy - r, cx + r, cy + r)
        self.canvas.itemconfig(self._dot, state="hidden")
        self._move_history.clear()

# ─── Main Overlay ──────────────────────────────────────────────────────────────

class KeyOverlay:
    def __init__(self, root, cfg):
        self.root = root
        self.cfg  = cfg
        self.key_widgets  = {}
        self.kb_listener  = None
        self.mouse_listener = None
        self.mouse_widget = None

        self._build_window()
        self._build_keys()
        self._start_listeners()

    # ── Window ────────────────────────────────────────────────────────────────

    def _build_window(self):
        cfg = self.cfg
        self.root.title("Key Overlay")
        self.root.resizable(False, False)
        self.root.configure(bg=cfg["bg_color"])
        self.root.geometry(f"+{cfg['window_x']}+{cfg['window_y']}")
        self._apply_attrs()

        menubar = tk.Menu(self.root, bg="#1a1a1a", fg="white",
                          activebackground="#00d4ff", activeforeground="black")
        self.root.config(menu=menubar)

        mode_menu = tk.Menu(menubar, tearoff=0, bg="#1a1a1a", fg="white",
                            activebackground="#00d4ff", activeforeground="black")
        menubar.add_cascade(label="Mode", menu=mode_menu)
        mode_menu.add_command(label="Osu",              command=lambda: self._set_mode("osu"))
        mode_menu.add_command(label="Gaming",           command=lambda: self._set_mode("gaming"))
        mode_menu.add_command(label="Full KB",          command=lambda: self._set_mode("fullkb"))
        mode_menu.add_command(label="Full KB + Numpad", command=lambda: self._set_mode("fullkb_num"))

        settings_menu = tk.Menu(menubar, tearoff=0, bg="#1a1a1a", fg="white",
                                activebackground="#00d4ff", activeforeground="black")
        menubar.add_cascade(label="Settings", menu=settings_menu)
        settings_menu.add_command(label="Edit Osu Keys...", command=self._edit_osu_keys)
        settings_menu.add_command(label="Colors...",        command=self._open_colors)
        settings_menu.add_command(label="Key Size...",      command=self._edit_key_size)
        settings_menu.add_separator()
        self.topmost_var = tk.BooleanVar(value=cfg["always_on_top"])
        settings_menu.add_checkbutton(label="Always on Top", variable=self.topmost_var,
                                      command=self._toggle_topmost)

        menubar.add_command(label="GitHub", command=self._open_github)

        self.outer = tk.Frame(self.root, bg=cfg["bg_color"])
        self.outer.pack(padx=6, pady=6)

        # keyboard frame (left) and mouse frame (right) sit side by side
        self.frame = tk.Frame(self.outer, bg=cfg["bg_color"])
        self.frame.pack(side="left")

        self.mouse_frame = tk.Frame(self.outer, bg=cfg["bg_color"])
        self.mouse_frame.pack(side="left", padx=(16, 0))

        self.root.bind("<Configure>", self._on_configure)

    def _apply_attrs(self):
        cfg = self.cfg
        self.root.wm_attributes("-topmost", cfg["always_on_top"])
        try:
            self.root.wm_attributes("-alpha", cfg["opacity"])
        except Exception:
            pass
        if sys.platform == "win32":
            try:
                self.root.wm_attributes("-transparentcolor", cfg["bg_color"])
            except Exception:
                pass

    def _on_configure(self, event):
        if event.widget is self.root:
            x, y = self.root.winfo_x(), self.root.winfo_y()
            if x != self.cfg.get("window_x") or y != self.cfg.get("window_y"):
                self.cfg["window_x"] = x
                self.cfg["window_y"] = y
                save_config(self.cfg)

    # ── Key building ──────────────────────────────────────────────────────────

    def _clear_frame(self):
        for w in self.frame.winfo_children():
            w.destroy()
        for w in self.mouse_frame.winfo_children():
            w.destroy()
        self.key_widgets.clear()
        self.mouse_widget = None

    def _build_keys(self):
        self._clear_frame()
        mode = self.cfg["mode"]
        if mode == "gaming":
            self._build_gaming()
            self._build_mouse()
            self.mouse_frame.pack(side="left", padx=(16, 0))
        else:
            self.mouse_frame.pack_forget()
            if mode == "osu":
                self._build_osu()
            elif mode == "fullkb":
                self._build_fullkb(numpad=False)
            elif mode == "fullkb_num":
                self._build_fullkb(numpad=True)
        # Force window to shrink/grow to exactly fit new content
        self.root.update_idletasks()
        self.root.geometry("")

    def _build_osu(self):
        keys = self.cfg["osu_keys"]
        cfg  = self.cfg
        s    = cfg["key_size"]
        n    = len(keys)
        total_w = s * n + 2

        c = tk.Canvas(self.frame, width=total_w, height=s + 2,
                      bg=cfg["bg_color"], highlightthickness=0)
        c.pack()

        for i, key in enumerate(keys):
            x0, x1 = i * s, (i + 1) * s
            y0, y1 = 0, s
            rect = c.create_rectangle(x0, y0, x1, y1,
                                      fill=cfg["key_color"],
                                      outline=cfg["border_color"], width=1)
            fs = cfg["font_size"] if len(key) <= 3 else max(7, cfg["font_size"] - 4)
            text = c.create_text((x0+x1)//2, (y0+y1)//2, text=key,
                                  fill=cfg["text_color"],
                                  font=("Consolas", fs, "bold"))
            self.key_widgets[key.upper()] = (c, rect, text)

    def _build_gaming(self):
        cfg  = self.cfg
        s    = cfg["key_size"]
        rows = GAMING_KEYS
        cols = max(len(r) for r in rows)
        total_w = cols * s + 1
        total_h = len(rows) * s + 1

        c = tk.Canvas(self.frame, width=total_w, height=total_h,
                      bg=cfg["bg_color"], highlightthickness=0)
        c.pack()

        for r, row in enumerate(rows):
            for col, key in enumerate(row):
                if not key:
                    continue
                x0, y0 = col * s, r * s
                x1, y1 = x0 + s, y0 + s
                rect = c.create_rectangle(x0, y0, x1, y1,
                                          fill=cfg["key_color"],
                                          outline=cfg["border_color"], width=1)
                fs = cfg["font_size"] if len(key) <= 3 else max(7, cfg["font_size"] - 4)
                text = c.create_text((x0+x1)//2, (y0+y1)//2, text=key,
                                      fill=cfg["text_color"],
                                      font=("Consolas", fs, "bold"))
                self.key_widgets[key.upper()] = (c, rect, text)

    def _build_mouse(self):
        """Create mouse widget sized to match the gaming keyboard height."""
        cfg = self.cfg
        s   = cfg["key_size"]
        kb_h = len(GAMING_KEYS) * s
        mw_h = kb_h
        mw_w = max(int(mw_h * 0.7), 100)

        self.mouse_widget = MouseWidget(self.mouse_frame, cfg,
                                        width=mw_w, height=mw_h)
        self.mouse_widget.pack(side="left")

    def _build_fullkb(self, numpad=False):
        cfg = self.cfg
        s   = cfg["key_size"]
        U   = s

        kb_units = 14.5
        kb_w = int(kb_units * U) + 1

        np_gap   = s // 2
        np_units = 4.0
        np_w     = int(np_units * U) + 1

        total_w = kb_w + (np_gap + np_w if numpad else 0)
        total_h = len(FULL_KB_ROWS) * s + 1

        c = tk.Canvas(self.frame, width=total_w, height=total_h,
                      bg=cfg["bg_color"], highlightthickness=0)
        c.pack()

        self._draw_kb_rows(c, FULL_KB_ROWS, U, x_offset=0)

        if numpad:
            self._draw_numpad(c, U, x_offset=kb_w + np_gap)

    def _draw_kb_rows(self, c, rows, U, x_offset=0):
        cfg = self.cfg
        s   = cfg["key_size"]

        for r, row in enumerate(rows):
            x = x_offset
            y0 = r * s
            y1 = y0 + s
            for (label, w_mult) in row:
                key_w = int(w_mult * U)
                x0, x1 = x, x + key_w
                rect = c.create_rectangle(x0, y0, x1, y1,
                                          fill=cfg["key_color"],
                                          outline=cfg["border_color"], width=1)
                fs = cfg["font_size"] if len(label) <= 3 else max(7, cfg["font_size"] - 4)
                text = c.create_text((x0+x1)//2, (y0+y1)//2, text=label,
                                      fill=cfg["text_color"],
                                      font=("Consolas", fs, "bold"))
                k = label.upper()
                if k and k not in self.key_widgets:
                    self.key_widgets[k] = (c, rect, text)
                x += key_w

    def _draw_numpad(self, c, U, x_offset=0):
        cfg = self.cfg
        s   = cfg["key_size"]

        def key(label, col, row, w=1, h=1):
            x0 = x_offset + col * U
            y0 = row * s
            x1 = x0 + w * U
            y1 = y0 + h * s
            rect = c.create_rectangle(x0, y0, x1, y1,
                                      fill=cfg["key_color"],
                                      outline=cfg["border_color"], width=1)
            fs = cfg["font_size"] if len(label) <= 3 else max(7, cfg["font_size"] - 4)
            text = c.create_text((x0+x1)//2, (y0+y1)//2, text=label,
                                  fill=cfg["text_color"],
                                  font=("Consolas", fs, "bold"))
            if label not in self.key_widgets:
                self.key_widgets[label.upper()] = (c, rect, text)

        key("NL",0,0); key("NP/",1,0); key("NP*",2,0); key("NP-",3,0)
        key("NP7",0,1); key("NP8",1,1); key("NP9",2,1); key("NP+",3,1,h=2)
        key("NP4",0,2); key("NP5",1,2); key("NP6",2,2)
        key("NP1",0,3); key("NP2",1,3); key("NP3",2,3); key("NPENT",3,3,h=2)
        key("NP0",0,4,w=2); key("NP.",2,4)

    # ── Key press/release ─────────────────────────────────────────────────────

    def _press_key(self, key_str):
        k = key_str.upper()
        if k in self.key_widgets:
            c, rect, text = self.key_widgets[k]
            c.itemconfig(rect, fill=self.cfg["key_active_color"],
                         outline=self.cfg["border_active_color"])
            c.itemconfig(text, fill=self.cfg["text_active_color"])

    def _release_key(self, key_str):
        k = key_str.upper()
        if k in self.key_widgets:
            c, rect, text = self.key_widgets[k]
            c.itemconfig(rect, fill=self.cfg["key_color"],
                         outline=self.cfg["border_color"])
            c.itemconfig(text, fill=self.cfg["text_color"])

    # pynput numpad key.name  →  widget label
    NUMPAD_NAME_MAP = {
        "num_lock":   "NL",
        "divide":     "NP/",
        "multiply":   "NP*",
        "subtract":   "NP-",
        "add":        "NP+",
        "decimal":    "NP.",
        "enter":      "NPENT",   # numpad enter (key.name == 'enter' when is_numpad)
        "key_0":      "NP0",
        "key_1":      "NP1",
        "key_2":      "NP2",
        "key_3":      "NP3",
        "key_4":      "NP4",
        "key_5":      "NP5",
        "key_6":      "NP6",
        "key_7":      "NP7",
        "key_8":      "NP8",
        "key_9":      "NP9",
        # Some pynput versions use these names instead
        "numpad_0":   "NP0",
        "numpad_1":   "NP1",
        "numpad_2":   "NP2",
        "numpad_3":   "NP3",
        "numpad_4":   "NP4",
        "numpad_5":   "NP5",
        "numpad_6":   "NP6",
        "numpad_7":   "NP7",
        "numpad_8":   "NP8",
        "numpad_9":   "NP9",
    }

    # Windows VK code → widget label
    VK_MAP = {
        96: "NP0", 97: "NP1", 98: "NP2", 99: "NP3",
        100: "NP4", 101: "NP5", 102: "NP6", 103: "NP7",
        104: "NP8", 105: "NP9",
        106: "NP*", 107: "NP+", 109: "NP-",
        110: "NP.", 111: "NP/",
        144: "NL",
    }

    def _normalize_key(self, key):
        vk = getattr(key, 'vk', None)

        # VK-based match first (catches numpad keys where name=None)
        if vk and vk in self.VK_MAP:
            return self.VK_MAP[vk]

        try:
            name = key.name
            if name is None:
                raise AttributeError

            if name in self.NUMPAD_NAME_MAP:
                return self.NUMPAD_NAME_MAP[name]

            rev = {v: k for k, v in KEY_MAP.items() if v}
            if name in rev:
                return rev[name].upper()
            for base in ["shift", "ctrl", "alt", "cmd"]:
                if name.startswith(base):
                    for dk, dv in KEY_MAP.items():
                        if dv == base:
                            return dk.upper()
            return name.upper()
        except AttributeError:
            try:
                ch = key.char
                if ch:
                    return ch.upper()
            except Exception:
                pass
            return None

    # ── Listeners ─────────────────────────────────────────────────────────────

    def _start_listeners(self):
        self._start_kb_listener()
        self._start_mouse_listener()

    def _start_kb_listener(self):
        if not PYNPUT_AVAILABLE:
            return
        def on_press(key):
            k = self._normalize_key(key)
            if k:
                self.root.after(0, self._press_key, k)
        def on_release(key):
            k = self._normalize_key(key)
            if k:
                self.root.after(0, self._release_key, k)
        self.kb_listener = pynput_kb.Listener(on_press=on_press, on_release=on_release)
        self.kb_listener.daemon = True
        self.kb_listener.start()

    def _start_mouse_listener(self):
        if not MOUSE_AVAILABLE:
            return

        def btn_name(button):
            n = str(button).lower()
            if "left"   in n: return "lmb"
            if "right"  in n: return "rmb"
            if "middle" in n: return "mmb"
            if "x1"     in n or "button4" in n or "4" in n: return "m4"
            if "x2"     in n or "button5" in n or "5" in n: return "m5"
            return None

        def on_click(x, y, button, pressed):
            b = btn_name(button)
            if not b or not self.mouse_widget:
                return
            if pressed:
                self.root.after(0, self.mouse_widget.press, b)
            else:
                self.root.after(0, self.mouse_widget.release, b)

        def on_scroll(x, y, dx, dy):
            if not self.mouse_widget:
                return
            self.root.after(0, self.mouse_widget.scroll, "up" if dy > 0 else "down")

        def on_move(x, y):
            if not self.mouse_widget:
                return
            self.root.after(0, self.mouse_widget.on_move, x, y)

        self.mouse_listener = pynput_mouse.Listener(
            on_click=on_click,
            on_scroll=on_scroll,
            on_move=on_move,
        )
        self.mouse_listener.daemon = True
        self.mouse_listener.start()

    # ── Settings ──────────────────────────────────────────────────────────────

    def _set_mode(self, mode):
        self.cfg["mode"] = mode
        self._build_keys()
        save_config(self.cfg)

    def _edit_osu_keys(self):
        current = ", ".join(self.cfg["osu_keys"])
        result = simpledialog.askstring(
            "Edit Osu Keys",
            "Enter keys separated by commas (e.g. Z, X, C):",
            initialvalue=current, parent=self.root)
        if result:
            keys = [k.strip().upper() for k in result.split(",") if k.strip()]
            if keys:
                self.cfg["osu_keys"] = keys
                save_config(self.cfg)
                if self.cfg["mode"] == "osu":
                    self._build_keys()

    def _edit_key_size(self):
        result = simpledialog.askinteger(
            "Key Size", "Enter key size in pixels (30-150):",
            initialvalue=self.cfg["key_size"], minvalue=30, maxvalue=150,
            parent=self.root)
        if result:
            self.cfg["key_size"] = result
            self.cfg["font_size"] = max(8, result // 4)
            save_config(self.cfg)
            self._build_keys()

    def _open_colors(self):
        win = tk.Toplevel(self.root)
        win.title("Colors & Opacity")
        win.configure(bg="#111")
        win.resizable(False, False)
        win.wm_attributes("-topmost", True)

        fields = [
            ("Background",      "bg_color"),
            ("Key (idle)",      "key_color"),
            ("Key (active)",    "key_active_color"),
            ("Text (idle)",     "text_color"),
            ("Text (active)",   "text_active_color"),
            ("Border (idle)",   "border_color"),
            ("Border (active)", "border_active_color"),
        ]

        def pick(field, btn):
            color = colorchooser.askcolor(color=self.cfg[field], parent=win)[1]
            if color:
                self.cfg[field] = color
                btn.configure(bg=color)
                save_config(self.cfg)
                self.root.configure(bg=self.cfg["bg_color"])
                self.outer.configure(bg=self.cfg["bg_color"])
                self.frame.configure(bg=self.cfg["bg_color"])
                self.mouse_frame.configure(bg=self.cfg["bg_color"])
                self._apply_attrs()
                self._build_keys()

        for i, (lbl, field) in enumerate(fields):
            tk.Label(win, text=lbl, bg="#111", fg="white",
                     font=("Consolas", 10)).grid(row=i, column=0, padx=12, pady=4, sticky="w")
            btn = tk.Button(win, bg=self.cfg[field], width=4, relief="flat", cursor="hand2")
            btn.configure(command=lambda f=field, b=btn: pick(f, b))
            btn.grid(row=i, column=1, padx=12, pady=4)

        row = len(fields)
        tk.Label(win, text="Opacity", bg="#111", fg="white",
                 font=("Consolas", 10)).grid(row=row, column=0, padx=12, pady=4, sticky="w")
        opacity_var = tk.DoubleVar(value=self.cfg["opacity"])
        def set_opacity(val):
            v = round(float(val), 2)
            self.cfg["opacity"] = v
            try:
                self.root.wm_attributes("-alpha", v)
            except Exception:
                pass
            save_config(self.cfg)
        tk.Scale(win, from_=0.1, to=1.0, resolution=0.05, orient="horizontal",
                 variable=opacity_var, command=set_opacity,
                 bg="#111", fg="white", troughcolor="#333",
                 highlightthickness=0, length=150).grid(row=row, column=1, padx=12, pady=4)

    def _open_github(self):
        import webbrowser
        webbrowser.open(_r())

    def _toggle_topmost(self):
        v = self.topmost_var.get()
        self.cfg["always_on_top"] = v
        self.root.wm_attributes("-topmost", v)
        save_config(self.cfg)

    def on_close(self):
        self.cfg["window_x"] = self.root.winfo_x()
        self.cfg["window_y"] = self.root.winfo_y()
        save_config(self.cfg)
        if self.kb_listener:
            self.kb_listener.stop()
        if self.mouse_listener:
            self.mouse_listener.stop()
        self.root.destroy()


# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    if not PYNPUT_AVAILABLE:
        print("pynput not found — install it with:  pip install pynput")

    cfg  = load_config()
    root = tk.Tk()
    app  = KeyOverlay(root, cfg)
    root.protocol("WM_DELETE_WINDOW", app.on_close)

    try:
        import ctypes
        root.update()
        hwnd = ctypes.windll.user32.GetParent(root.winfo_id())
        ctypes.windll.dwmapi.DwmSetWindowAttribute(
            hwnd, 20, ctypes.byref(ctypes.c_int(1)), 4)
    except Exception:
        pass

    root.mainloop()

if __name__ == "__main__":
    main()